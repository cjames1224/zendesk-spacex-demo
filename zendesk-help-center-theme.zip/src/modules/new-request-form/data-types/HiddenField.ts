export interface HiddenField {
  type: "hidden";
  name: string;
  value: string;
}
