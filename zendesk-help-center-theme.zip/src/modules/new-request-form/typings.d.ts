declare module "@zendeskgarden/svg-icons/*";
declare module "@zendesk/help-center-wysiwyg";
