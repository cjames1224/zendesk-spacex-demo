export const APPROVAL_REQUEST_STATES = {
  ACTIVE: "active",
  APPROVED: "approved",
  REJECTED: "rejected",
  WITHDRAWN: "withdrawn",
} as const;
