interface Window {
  NewRequestForm?: {
    initializeWysiwyg: (element: HTMLTextAreaElement) => void;
  };
}
