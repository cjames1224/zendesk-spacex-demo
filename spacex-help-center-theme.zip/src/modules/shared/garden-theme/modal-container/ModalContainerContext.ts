import { createContext } from "react";

export const ModalContainerContext = createContext<HTMLDivElement | null>(null);
