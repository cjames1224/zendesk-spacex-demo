export interface Meta {
  before_cursor: string;
  after_cursor: string;
  has_more: boolean;
}
